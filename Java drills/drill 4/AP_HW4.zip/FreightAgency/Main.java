/**
 * Run and test the program
 *
 * @author Narges Salehi & Mohammadreza Ghaderi
 * @version 1.1
 * @since October 2020
 */

public class Main {
    public static void main(String[] args) {


    }
}
